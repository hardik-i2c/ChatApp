# Use the app

```
this is chat app with Node js graphql and mysql
```
